# 🐍 GeeksForGeeks — 51 Problems Solved (Python)

> Progress: **51 / 798** | All solutions in Python 3

---

## 📁 Folder Structure

```
GFG-51-Solutions/
└── Arrays/
    ├── Easy/        → 18 problems
    ├── Medium/      → 28 problems
    ├── Hard/        →  1 problem
    └── Basic/       →  4 problems
```

---

## ✅ All 51 Problems

| # | Problem | Difficulty | Key Concept |
|---|---------|------------|-------------|
| 01 | Indexes of Subarray Sum | Medium | Sliding Window |
| 02 | Missing in Array | Easy | XOR / Sum Formula |
| 03 | Second Largest | Easy | Single Pass |
| 04 | Kadane's Algorithm | Medium | DP / Greedy |
| 05 | Minimum Jumps | Medium | Greedy |
| 06 | Array Leaders | Easy | Right Traversal |
| 07 | Array Duplicates | Easy | Index Negation |
| 08 | Sort 0s, 1s and 2s | Medium | Dutch National Flag |
| 09 | Majority Element | Medium | Boyer-Moore Voting |
| 10 | Longest Subarray with Sum K | Medium | Prefix Sum + HashMap |
| 11 | Minimize the Heights II | Medium | Sort + Greedy |
| 12 | Count Inversions | Medium | Merge Sort |
| 13 | Kth Smallest | Medium | Max-Heap |
| 14 | Binary Search | Easy | Binary Search |
| 15 | Missing And Repeating | Easy | Math (Sum + Sum²) |
| 16 | Equilibrium Point | Easy | Prefix Sum |
| 17 | Rotate Array | Medium | Reversal Algorithm |
| 18 | Peak Element | Medium | Binary Search |
| 19 | Minimum Platforms | Medium | Sort + Two Pointer |
| 20 | Largest in Array | Basic | Linear Scan |
| 21 | Array Search | Basic | Linear Search |
| 22 | Array Subset | Basic | Frequency Map |
| 23 | Two Sum - Pairs with 0 Sum | Easy | HashSet |
| 24 | Union of 2 Sorted Arrays | Medium | Two Pointer |
| 25 | Trapping Rain Water | Hard | Two Pointer |
| 26 | Maximum Product Subarray | Medium | Track max & min |
| 27 | Union of Arrays with Duplicates | Easy | Set Union |
| 28 | Smallest Positive Missing | Medium | Index Placement |
| 29 | Two Sum - Pair with Given Sum | Easy | HashSet |
| 30 | Largest Subarray with 0 Sum | Medium | Prefix Sum + HashMap |
| 31 | Move All Zeroes to End | Easy | Two Pointer |
| 32 | K Sized Subarray Maximum | Medium | Monotonic Deque |
| 33 | Check Equal Arrays | Easy | Counter / HashMap |
| 34 | Min and Max in Array | Basic | Single Pass |
| 35 | K-th element of two Arrays | Medium | Binary Search |
| 36 | Frequencies in a Limited Array | Easy | Index Counting |
| 37 | Number of Occurrence | Easy | Binary Search |
| 38 | Row with Max 1s | Medium | Top-Right Walk |
| 39 | Reverse Array in Groups | Medium | In-place Reversal |
| 40 | Check if Array is Sorted | Easy | Single Pass |
| 41 | The Celebrity Problem | Medium | Two Pointer |
| 42 | Triplet Sum in Array | Medium | Sort + Two Pointer |
| 43 | Rotate Array by One | Basic | Shift Right |
| 44 | Remove Duplicates Sorted Array | Easy | Two Pointer |
| 45 | Find Triplets with Zero Sum | Medium | Sort + Two Pointer |
| 46 | Find Kth Rotation | Easy | Binary Search |
| 47 | Spirally Traversing a Matrix | Medium | Layer Peeling |
| 48 | Merge Without Extra Space | Medium | Gap Method |
| 49 | First Repeating Element | Easy | HashSet (right→left) |
| 50 | Longest Common Prefix of Strings | Easy | Sort + Compare |
| 51 | Implement Stack Using Array | Medium | Array + Top Pointer |

---

## 🛠️ How to Run Any Solution

```bash
python3 Arrays/Medium/04_kadanes_algorithm.py
```

---

## 💡 Algorithms Covered

- Sliding Window · Two Pointer · Binary Search
- Prefix Sum · Hashing · Sorting
- Greedy · Divide & Conquer (Merge Sort)
- Stack · Heap · Dutch National Flag
- Matrix Traversal · Boyer-Moore Voting

---
⭐ Star this repo if it helped you!
