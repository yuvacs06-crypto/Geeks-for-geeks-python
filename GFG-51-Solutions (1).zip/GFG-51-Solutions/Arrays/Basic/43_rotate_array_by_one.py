# GFG: Rotate Array by One
# Difficulty: Basic | Submissions: 361K | Accuracy: 69.6%
# Link: https://www.geeksforgeeks.org/problems/cyclically-rotate-an-array-by-one2614/1
#
# Problem: Cyclically rotate array by one position to the right.
# Approach: Store last element, shift right — O(n) time, O(1) space

def rotate_by_one(arr):
    last = arr[-1]
    for i in range(len(arr) - 1, 0, -1):
        arr[i] = arr[i - 1]
    arr[0] = last


if __name__ == "__main__":
    a = [1, 2, 3, 4, 5]; rotate_by_one(a); print(a)   # [5, 1, 2, 3, 4]
    b = [9, 8, 7, 6, 4, 2, 1, 3]; rotate_by_one(b); print(b)  # [3,9,8,7,6,4,2,1]
