# GFG: Largest in Array
# Difficulty: Basic | Submissions: 584K | Accuracy: 67.48%
# Link: https://www.geeksforgeeks.org/problems/largest-element-in-array4009/1
#
# Problem: Find the largest element in an array.
# Approach: Single Pass — O(n) time, O(1) space

def largest(arr):
    result = arr[0]
    for val in arr[1:]:
        if val > result:
            result = val
    return result


if __name__ == "__main__":
    print(largest([1, 8, 7, 56, 90]))  # 90
    print(largest([5, 5, 5]))          # 5
    print(largest([10]))               # 10
