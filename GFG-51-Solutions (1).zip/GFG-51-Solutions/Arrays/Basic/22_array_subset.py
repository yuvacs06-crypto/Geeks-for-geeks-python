# GFG: Array Subset
# Difficulty: Basic | Submissions: 537K | Accuracy: 44.05%
# Link: https://www.geeksforgeeks.org/problems/array-subset-of-another-array2317/1
#
# Problem: Check if array b is a subset of array a (including duplicates).
# Approach: Frequency Map — O(n + m) time, O(n) space

from collections import Counter

def is_subset(a, b):
    freq = Counter(a)
    for val in b:
        if freq.get(val, 0) == 0:
            return False
        freq[val] -= 1
    return True


if __name__ == "__main__":
    print(is_subset([11, 7, 1, 13, 21, 3, 7, 3], [11, 3, 7, 1, 7]))  # True
    print(is_subset([1, 2, 3, 4, 5], [1, 2, 9]))                      # False
    print(is_subset([10, 5, 2, 3, 1], [3, 2, 5, 10, 1]))              # True
