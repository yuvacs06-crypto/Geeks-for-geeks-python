# GFG: Array Search
# Difficulty: Basic | Submissions: 543K | Accuracy: 40.95%
# Link: https://www.geeksforgeeks.org/problems/search-an-element-in-an-array-1587115621/1
#
# Problem: Search for element x in array. Return its index, else -1.
# Approach: Linear Search — O(n) time, O(1) space

def search(arr, x):
    for i, val in enumerate(arr):
        if val == x:
            return i
    return -1


if __name__ == "__main__":
    print(search([1, 2, 3, 4, 5], 3))  # 2
    print(search([1, 2, 3, 4, 5], 6))  # -1
    print(search([5], 5))              # 0
