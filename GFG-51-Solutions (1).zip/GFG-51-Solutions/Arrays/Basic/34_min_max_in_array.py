# GFG: Min and Max in Array
# Difficulty: Basic | Submissions: 411K | Accuracy: 68.55%
# Link: https://www.geeksforgeeks.org/problems/find-minimum-and-maximum-element-in-an-array4428/1
#
# Problem: Find minimum and maximum element in an array.
# Approach: Single Pass — O(n) time, O(1) space

def min_max(arr):
    mn = mx = arr[0]
    for val in arr[1:]:
        if val < mn: mn = val
        if val > mx: mx = val
    return mn, mx


if __name__ == "__main__":
    print(min_max([3, 2, 1, 56, 10000, 167]))  # (1, 10000)
    print(min_max([1]))                         # (1, 1)
    print(min_max([-5, -1, -3]))                # (-5, -1)
