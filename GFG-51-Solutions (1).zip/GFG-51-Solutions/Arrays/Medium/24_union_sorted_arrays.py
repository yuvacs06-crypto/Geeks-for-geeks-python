# GFG: Union of 2 Sorted Arrays
# Difficulty: Medium | Submissions: 526K | Accuracy: 31.39%
# Link: https://www.geeksforgeeks.org/problems/union-of-two-sorted-arrays-1587115621/1
#
# Problem: Return sorted union of two sorted arrays (no duplicates).
# Approach: Two Pointer — O(n + m) time, O(1) extra space

def union_sorted_arrays(a, b):
    result = []
    i = j = 0

    while i < len(a) and j < len(b):
        # Skip duplicates
        while i > 0 and i < len(a) and a[i] == a[i - 1]: i += 1
        while j > 0 and j < len(b) and b[j] == b[j - 1]: j += 1
        if i >= len(a) or j >= len(b): break

        if a[i] < b[j]:
            if not result or result[-1] != a[i]: result.append(a[i])
            i += 1
        elif b[j] < a[i]:
            if not result or result[-1] != b[j]: result.append(b[j])
            j += 1
        else:
            if not result or result[-1] != a[i]: result.append(a[i])
            i += 1; j += 1

    while i < len(a):
        if not result or result[-1] != a[i]: result.append(a[i])
        i += 1
    while j < len(b):
        if not result or result[-1] != b[j]: result.append(b[j])
        j += 1

    return result


if __name__ == "__main__":
    print(union_sorted_arrays([1, 2, 3, 4, 5], [1, 2, 3, 6, 7]))  # [1,2,3,4,5,6,7]
    print(union_sorted_arrays([2, 2, 3, 4, 5], [1, 1, 2, 3, 4]))  # [1,2,3,4,5]
