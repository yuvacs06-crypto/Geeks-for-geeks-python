# GFG: Indexes of Subarray Sum
# Difficulty: Medium | Submissions: 2M | Accuracy: 16.5%
# Link: https://www.geeksforgeeks.org/problems/subarray-with-given-sum-1587115621/1
#
# Problem: Given array of non-negative integers and a target, find subarray
#          that adds to target. Return 1-based [start, end]. Else [-1].
# Approach: Sliding Window — O(n) time, O(1) space

def subarray_sum(arr, target):
    start = 0
    curr_sum = 0

    for end in range(len(arr)):
        curr_sum += arr[end]

        while curr_sum > target and start < end:
            curr_sum -= arr[start]
            start += 1

        if curr_sum == target:
            return [start + 1, end + 1]   # 1-based

    return [-1]


if __name__ == "__main__":
    print(subarray_sum([1, 2, 3, 7, 5], 12))               # [2, 4]
    print(subarray_sum([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 15))  # [1, 5]
    print(subarray_sum([5, 3, 4], 2))                       # [-1]
