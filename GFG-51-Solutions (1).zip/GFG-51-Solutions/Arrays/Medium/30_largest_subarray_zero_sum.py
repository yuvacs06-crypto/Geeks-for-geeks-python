# GFG: Largest Subarray with 0 Sum
# Difficulty: Medium | Submissions: 458K | Accuracy: 41.84%
# Link: https://www.geeksforgeeks.org/problems/largest-subarray-with-0-sum/1
#
# Problem: Find length of the largest subarray with sum = 0.
# Approach: Prefix Sum + HashMap — O(n) time, O(n) space

def max_len_zero_sum(arr):
    prefix_map = {0: -1}
    prefix_sum = 0
    max_len = 0

    for i, val in enumerate(arr):
        prefix_sum += val
        if prefix_sum in prefix_map:
            max_len = max(max_len, i - prefix_map[prefix_sum])
        else:
            prefix_map[prefix_sum] = i

    return max_len


if __name__ == "__main__":
    print(max_len_zero_sum([15, -2, 2, -8, 1, 7, 10, 23]))  # 5
    print(max_len_zero_sum([2, 10, 4]))                      # 0
    print(max_len_zero_sum([1, 0, -4, 3, 1, 0]))             # 5
