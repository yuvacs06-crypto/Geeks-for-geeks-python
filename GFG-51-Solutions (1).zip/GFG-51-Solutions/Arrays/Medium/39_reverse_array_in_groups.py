# GFG: Reverse Array in Groups
# Difficulty: Medium | Submissions: 376K | Accuracy: 37.48%
# Link: https://www.geeksforgeeks.org/problems/reverse-array-in-groups0255/1
#
# Problem: Reverse every sub-array of size k.
# Approach: In-place reversal in chunks — O(n) time, O(1) space

def reverse_in_groups(arr, k):
    n = len(arr)
    for i in range(0, n, k):
        lo = i
        hi = min(i + k - 1, n - 1)
        while lo < hi:
            arr[lo], arr[hi] = arr[hi], arr[lo]
            lo += 1
            hi -= 1


if __name__ == "__main__":
    a = [1, 2, 3, 4, 5]; reverse_in_groups(a, 3); print(a)  # [3,2,1,5,4]
    b = [1, 2, 3, 4, 5, 6, 7, 8]; reverse_in_groups(b, 4); print(b)  # [4,3,2,1,8,7,6,5]
