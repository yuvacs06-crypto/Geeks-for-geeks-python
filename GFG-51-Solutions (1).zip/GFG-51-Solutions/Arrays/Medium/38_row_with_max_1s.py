# GFG: Row with max 1s
# Difficulty: Medium | Submissions: 381K | Accuracy: 33.09%
# Link: https://www.geeksforgeeks.org/problems/row-with-max-1s0023/1
#
# Problem: Binary matrix with rows sorted. Find index of row with most 1s. Return -1 if no 1.
# Approach: Start from top-right corner — O(n + m) time, O(1) space

def row_with_max1s(mat):
    rows, cols = len(mat), len(mat[0])
    col = cols - 1
    best_row = -1

    for row in range(rows):
        while col >= 0 and mat[row][col] == 1:
            col -= 1
            best_row = row

    return best_row


if __name__ == "__main__":
    mat1 = [[0, 1, 1, 1], [0, 0, 1, 1], [1, 1, 1, 1], [0, 0, 0, 0]]
    print(row_with_max1s(mat1))  # 2

    mat2 = [[0, 0], [1, 1]]
    print(row_with_max1s(mat2))  # 1

    mat3 = [[0, 0], [0, 0]]
    print(row_with_max1s(mat3))  # -1
