# GFG: Smallest Positive Missing
# Difficulty: Medium | Submissions: 470K | Accuracy: 25.13%
# Link: https://www.geeksforgeeks.org/problems/smallest-positive-missing-number-1587115621/1
#
# Problem: Find smallest positive integer missing from unsorted array.
# Approach: Index placement — O(n) time, O(1) space

def smallest_positive_missing(arr):
    n = len(arr)

    # Place each value at its correct index (val-1)
    for i in range(n):
        while 1 <= arr[i] <= n and arr[arr[i] - 1] != arr[i]:
            arr[arr[i] - 1], arr[i] = arr[i], arr[arr[i] - 1]

    # First index where arr[i] != i+1 is the answer
    for i in range(n):
        if arr[i] != i + 1:
            return i + 1

    return n + 1


if __name__ == "__main__":
    print(smallest_positive_missing([1, 2, 3, 4, 5]))   # 6
    print(smallest_positive_missing([0, -10, 1, 3, -20]))  # 2
    print(smallest_positive_missing([2, 3, 7, 6, 8, -1, -10, 15]))  # 1
