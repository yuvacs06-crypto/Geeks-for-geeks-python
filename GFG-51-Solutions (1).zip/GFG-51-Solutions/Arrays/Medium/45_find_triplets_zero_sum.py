# GFG: Find Triplets with Zero Sum
# Difficulty: Medium | Submissions: 353K | Accuracy: 25.81%
# Link: https://www.geeksforgeeks.org/problems/find-triplets-with-zero-sum/1
#
# Problem: Find all unique triplets that sum to zero.
# Approach: Sort + Two Pointer — O(n²) time, O(1) extra space

def find_triplets_zero_sum(arr):
    arr.sort()
    n = len(arr)
    result = []

    for i in range(n - 2):
        if i > 0 and arr[i] == arr[i - 1]:
            continue   # skip duplicates

        lo, hi = i + 1, n - 1
        while lo < hi:
            s = arr[i] + arr[lo] + arr[hi]
            if s == 0:
                result.append([arr[i], arr[lo], arr[hi]])
                while lo < hi and arr[lo] == arr[lo + 1]: lo += 1
                while lo < hi and arr[hi] == arr[hi - 1]: hi -= 1
                lo += 1; hi -= 1
            elif s < 0:
                lo += 1
            else:
                hi -= 1

    return result


if __name__ == "__main__":
    print(find_triplets_zero_sum([0, -1, 2, -3, 1]))   # [[-3,1,2],[-1,0,1]]
    print(find_triplets_zero_sum([1, -2, 1, 0, 5]))    # [[-2,1,1]]
    print(find_triplets_zero_sum([0, 0, 0]))            # [[0,0,0]]
