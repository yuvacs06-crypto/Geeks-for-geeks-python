# GFG: The Celebrity Problem
# Difficulty: Medium | Submissions: 369K | Accuracy: 38.33%
# Link: https://www.geeksforgeeks.org/problems/the-celebrity-problem/1
#
# Problem: Celebrity is known by everyone but knows nobody.
#          Given knows(a, b) function, find celebrity index or -1.
# Approach: Two Pointer elimination — O(n) time, O(1) space

def find_celebrity(mat):
    n = len(mat)

    # Step 1: Find candidate
    candidate = 0
    for i in range(1, n):
        if mat[candidate][i] == 1:   # candidate knows i → candidate is not celebrity
            candidate = i

    # Step 2: Verify candidate
    for i in range(n):
        if i == candidate:
            continue
        # Celebrity must not know anyone AND be known by everyone
        if mat[candidate][i] == 1 or mat[i][candidate] == 0:
            return -1

    return candidate


if __name__ == "__main__":
    mat1 = [[0, 1, 0],
            [0, 0, 0],
            [0, 1, 0]]
    print(find_celebrity(mat1))  # 1

    mat2 = [[0, 1],
            [1, 0]]
    print(find_celebrity(mat2))  # -1
