# GFG: Minimize the Heights II
# Difficulty: Medium | Submissions: 777K | Accuracy: 15.06%
# Link: https://www.geeksforgeeks.org/problems/minimize-the-heights3351/1
#
# Problem: Add or subtract K from each tower. Minimize max-min difference.
# Approach: Sort + Greedy — O(n log n) time, O(1) space

def minimize_heights(arr, k):
    n = len(arr)
    if n == 1: return 0
    arr.sort()
    result = arr[-1] - arr[0]
    small, big = arr[0] + k, arr[-1] - k

    for i in range(n - 1):
        lo = min(small, arr[i + 1] - k)
        hi = max(big,   arr[i]     + k)
        if lo < 0: continue
        result = min(result, hi - lo)

    return result


if __name__ == "__main__":
    print(minimize_heights([1, 5, 8, 10], 2))       # 5
    print(minimize_heights([3, 9, 12, 16, 20], 3))  # 11
