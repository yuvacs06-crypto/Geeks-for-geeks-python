# GFG: Merge Without Extra Space
# Difficulty: Medium | Submissions: 330K | Accuracy: 32.01%
# Link: https://www.geeksforgeeks.org/problems/merge-two-sorted-arrays-1587115620/1
#
# Problem: Two sorted arrays a and b. Merge them in-place so a has
#          the smaller elements and b has the larger ones, both sorted.
# Approach: Gap method (Shell Sort idea) — O(n log n) time, O(1) space

import math

def merge_without_extra_space(a, b):
    n, m = len(a), len(b)
    gap = math.ceil((n + m) / 2)

    while gap > 0:
        i = 0
        j = gap

        while j < n + m:
            # Both pointers in a
            if j < n and a[i] > a[j]:
                a[i], a[j] = a[j], a[i]
            # i in a, j in b
            elif i < n <= j and a[i] > b[j - n]:
                a[i], b[j - n] = b[j - n], a[i]
            # Both in b
            elif i >= n and b[i - n] > b[j - n]:
                b[i - n], b[j - n] = b[j - n], b[i - n]
            i += 1
            j += 1

        gap = math.ceil(gap / 2) if gap > 1 else 0


if __name__ == "__main__":
    a = [1, 5, 9, 10, 15, 20]
    b = [2, 3, 8, 13]
    merge_without_extra_space(a, b)
    print(a, b)  # [1,2,3,5,8,9] [10,13,15,20]

    a2 = [2, 4, 7, 10]
    b2 = [2, 3]
    merge_without_extra_space(a2, b2)
    print(a2, b2)  # [2,2,3,4] [7,10]
