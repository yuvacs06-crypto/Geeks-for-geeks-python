# GFG: Kadane's Algorithm
# Difficulty: Medium | Submissions: 1M | Accuracy: 36.28%
# Link: https://www.geeksforgeeks.org/problems/kadanes-algorithm-1587115620/1
#
# Problem: Find the maximum sum contiguous subarray.
# Approach: Kadane's — O(n) time, O(1) space

def max_subarray_sum(arr):
    max_sum = curr = arr[0]
    for val in arr[1:]:
        curr = max(val, curr + val)
        max_sum = max(max_sum, curr)
    return max_sum


if __name__ == "__main__":
    print(max_subarray_sum([1, 2, 3, -2, 5]))         # 9
    print(max_subarray_sum([-1, -2, -3, -4]))          # -1
    print(max_subarray_sum([2, 3, -8, 7, -1, 2, 3]))  # 11
