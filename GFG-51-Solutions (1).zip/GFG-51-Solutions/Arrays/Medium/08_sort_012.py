# GFG: Sort 0s, 1s and 2s
# Difficulty: Medium | Submissions: 851K | Accuracy: 50.58%
# Link: https://www.geeksforgeeks.org/problems/sort-an-array-of-0s-1s-and-2s4231/1
#
# Problem: Sort array of only 0s, 1s, 2s in-place.
# Approach: Dutch National Flag — O(n) time, O(1) space

def sort_012(arr):
    lo = mid = 0
    hi = len(arr) - 1
    while mid <= hi:
        if arr[mid] == 0:
            arr[lo], arr[mid] = arr[mid], arr[lo]
            lo += 1; mid += 1
        elif arr[mid] == 1:
            mid += 1
        else:
            arr[mid], arr[hi] = arr[hi], arr[mid]
            hi -= 1


if __name__ == "__main__":
    a = [0, 1, 2, 0, 1, 2]; sort_012(a); print(a)  # [0,0,1,1,2,2]
    b = [0, 1, 1, 0, 1, 2, 1, 2, 0, 0, 0, 1]; sort_012(b); print(b)
