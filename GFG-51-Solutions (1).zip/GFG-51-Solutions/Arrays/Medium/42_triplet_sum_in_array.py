# GFG: Triplet Sum in Array
# Difficulty: Medium | Submissions: 367K | Accuracy: 35.0%
# Link: https://www.geeksforgeeks.org/problems/triplet-sum-in-array-1587115621/1
#
# Problem: Check if any triplet in array sums to a given target.
# Approach: Sort + Two Pointer — O(n²) time, O(1) space

def has_triplet_sum(arr, target):
    arr.sort()
    n = len(arr)

    for i in range(n - 2):
        lo, hi = i + 1, n - 1
        while lo < hi:
            s = arr[i] + arr[lo] + arr[hi]
            if s == target:
                return True
            elif s < target:
                lo += 1
            else:
                hi -= 1

    return False


if __name__ == "__main__":
    print(has_triplet_sum([1, 4, 45, 6, 10, 8], 13))   # True  (1+4+8)
    print(has_triplet_sum([1, 2, 4, 3, 6], 10))         # True  (1+3+6)
    print(has_triplet_sum([1, 2, 3], 10))               # False
