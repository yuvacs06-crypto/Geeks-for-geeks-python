# GFG: Peak Element
# Difficulty: Medium | Submissions: 625K | Accuracy: 38.86%
# Link: https://www.geeksforgeeks.org/problems/peak-element/1
#
# Problem: Find any peak element (greater than neighbours). arr[-1] = arr[n] = -inf.
# Approach: Binary Search — O(log n) time, O(1) space

def find_peak(arr):
    n = len(arr)
    lo, hi = 0, n - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        left_ok  = (mid == 0     or arr[mid] >= arr[mid - 1])
        right_ok = (mid == n - 1 or arr[mid] >= arr[mid + 1])
        if left_ok and right_ok:
            return mid
        if mid > 0 and arr[mid - 1] > arr[mid]:
            hi = mid - 1
        else:
            lo = mid + 1
    return -1


if __name__ == "__main__":
    print(find_peak([1, 2, 4, 5, 7, 8, 3]))       # 5  (value 8)
    print(find_peak([10, 20, 15, 2, 23, 90, 67])) # 1 or 5
    print(find_peak([1, 2, 3]))                    # 2
