# GFG: Rotate Array
# Difficulty: Medium | Submissions: 630K | Accuracy: 37.06%
# Link: https://www.geeksforgeeks.org/problems/rotate-array-by-n-elements-1587115621/1
#
# Problem: Left-rotate array by d positions.
# Approach: Reversal — O(n) time, O(1) space

def rotate_array(arr, d):
    n = len(arr)
    d %= n

    def reverse(lo, hi):
        while lo < hi:
            arr[lo], arr[hi] = arr[hi], arr[lo]
            lo += 1; hi -= 1

    reverse(0, d - 1)
    reverse(d, n - 1)
    reverse(0, n - 1)


if __name__ == "__main__":
    a = [1, 2, 3, 4, 5]; rotate_array(a, 2); print(a)   # [3, 4, 5, 1, 2]
    b = [1, 2, 3]; rotate_array(b, 4); print(b)          # [2, 3, 1]
