# GFG: Count Inversions
# Difficulty: Medium | Submissions: 761K | Accuracy: 16.93%
# Link: https://www.geeksforgeeks.org/problems/inversion-of-array-1587115620/1
#
# Problem: Count pairs (i,j) where i < j but arr[i] > arr[j].
# Approach: Merge Sort — O(n log n) time, O(n) space

def count_inversions(arr):
    def merge_sort(a):
        if len(a) <= 1:
            return a, 0
        mid = len(a) // 2
        left, li = merge_sort(a[:mid])
        right, ri = merge_sort(a[mid:])
        merged, si = merge(left, right)
        return merged, li + ri + si

    def merge(left, right):
        res, inv = [], 0
        i = j = 0
        while i < len(left) and j < len(right):
            if left[i] <= right[j]:
                res.append(left[i]); i += 1
            else:
                inv += len(left) - i
                res.append(right[j]); j += 1
        res.extend(left[i:]); res.extend(right[j:])
        return res, inv

    _, total = merge_sort(arr)
    return total


if __name__ == "__main__":
    print(count_inversions([2, 4, 1, 3, 5]))  # 3
    print(count_inversions([2, 3, 4, 5, 6]))  # 0
    print(count_inversions([5, 4, 3, 2, 1]))  # 10
