# GFG: K Sized Subarray Maximum
# Difficulty: Medium | Submissions: 438K | Accuracy: 26.04%
# Link: https://www.geeksforgeeks.org/problems/maximum-of-all-subarrays-of-size-k3101/1
#
# Problem: Find maximum of every window of size k.
# Approach: Monotonic Deque — O(n) time, O(k) space

from collections import deque

def max_of_subarrays(arr, k):
    dq = deque()  # stores indices; front always has max
    result = []

    for i in range(len(arr)):
        # Remove elements outside window
        while dq and dq[0] < i - k + 1:
            dq.popleft()

        # Remove smaller elements from back (they'll never be max)
        while dq and arr[dq[-1]] < arr[i]:
            dq.pop()

        dq.append(i)

        if i >= k - 1:
            result.append(arr[dq[0]])

    return result


if __name__ == "__main__":
    print(max_of_subarrays([1, 2, 3, 1, 4, 5, 2, 3, 6], 3))  # [3,3,4,5,5,5,6]
    print(max_of_subarrays([8, 5, 10, 7, 9, 4, 15, 12, 90, 13], 4))  # [10,10,10,15,15,90,90]
