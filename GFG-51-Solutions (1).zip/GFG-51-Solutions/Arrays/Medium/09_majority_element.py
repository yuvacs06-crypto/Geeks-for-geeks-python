# GFG: Majority Element
# Difficulty: Medium | Submissions: 812K | Accuracy: 27.82%
# Link: https://www.geeksforgeeks.org/problems/majority-element-1587115620/1
#
# Problem: Find element appearing more than n/2 times. Return -1 if none.
# Approach: Boyer-Moore Voting — O(n) time, O(1) space

def majority_element(arr):
    candidate, count = arr[0], 1
    for val in arr[1:]:
        count += 1 if val == candidate else -1
        if count == 0:
            candidate, count = val, 1
    # Verify
    return candidate if arr.count(candidate) > len(arr) // 2 else -1


if __name__ == "__main__":
    print(majority_element([3, 1, 3, 3, 2]))  # 3
    print(majority_element([7]))              # 7
    print(majority_element([2, 13]))          # -1
