# GFG: Implement Stack Using Array
# Difficulty: Medium | Submissions: 316K | Accuracy: 54.76%
# Link: https://www.geeksforgeeks.org/problems/implement-stack-using-array/1
#
# Problem: Implement a stack with push, pop, and peek using an array.
# Approach: Array with top pointer — O(1) per operation, O(n) space

class Stack:
    def __init__(self, capacity):
        self.capacity = capacity
        self.arr = [0] * capacity
        self.top = -1

    def push(self, val):
        if self.top == self.capacity - 1:
            print("Stack Overflow")
            return
        self.top += 1
        self.arr[self.top] = val

    def pop(self):
        if self.top == -1:
            print("Stack Underflow")
            return -1
        val = self.arr[self.top]
        self.top -= 1
        return val

    def peek(self):
        if self.top == -1:
            return -1
        return self.arr[self.top]

    def is_empty(self):
        return self.top == -1

    def size(self):
        return self.top + 1


if __name__ == "__main__":
    s = Stack(5)
    s.push(1)
    s.push(2)
    s.push(3)
    print(s.peek())   # 3
    print(s.pop())    # 3
    print(s.pop())    # 2
    print(s.peek())   # 1
    print(s.size())   # 1
    print(s.is_empty())  # False
    s.pop()
    print(s.is_empty())  # True
    s.pop()              # Stack Underflow
