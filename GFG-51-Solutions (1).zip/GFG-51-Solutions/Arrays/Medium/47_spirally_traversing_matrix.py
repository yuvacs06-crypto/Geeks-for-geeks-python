# GFG: Spirally Traversing a Matrix
# Difficulty: Medium | Submissions: 344K | Accuracy: 35.2%
# Link: https://www.geeksforgeeks.org/problems/spirally-traversing-a-matrix-1587115621/1
#
# Problem: Return all elements of a matrix in spiral order.
# Approach: Layer-by-layer peeling — O(n*m) time, O(1) extra space

def spiral_order(mat):
    result = []
    top, bottom = 0, len(mat) - 1
    left, right = 0, len(mat[0]) - 1

    while top <= bottom and left <= right:
        # Move right across top row
        for col in range(left, right + 1):
            result.append(mat[top][col])
        top += 1

        # Move down right column
        for row in range(top, bottom + 1):
            result.append(mat[row][right])
        right -= 1

        # Move left across bottom row
        if top <= bottom:
            for col in range(right, left - 1, -1):
                result.append(mat[bottom][col])
            bottom -= 1

        # Move up left column
        if left <= right:
            for row in range(bottom, top - 1, -1):
                result.append(mat[row][left])
            left += 1

    return result


if __name__ == "__main__":
    mat1 = [[1, 2, 3, 4],
            [5, 6, 7, 8],
            [9, 10, 11, 12],
            [13, 14, 15, 16]]
    print(spiral_order(mat1))  # [1,2,3,4,8,12,16,15,14,13,9,5,6,7,11,10]

    mat2 = [[1, 2, 3],
            [4, 5, 6],
            [7, 8, 9]]
    print(spiral_order(mat2))  # [1,2,3,6,9,8,7,4,5]
