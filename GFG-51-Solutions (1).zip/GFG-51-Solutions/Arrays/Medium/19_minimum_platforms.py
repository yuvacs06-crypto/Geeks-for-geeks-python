# GFG: Minimum Platforms
# Difficulty: Medium | Submissions: 625K | Accuracy: 26.84%
# Link: https://www.geeksforgeeks.org/problems/minimum-number-of-platforms-required-for-a-railway1229/1
#
# Problem: Given arrival and departure times of trains, find minimum platforms needed.
# Approach: Sort + Two Pointer — O(n log n) time, O(1) space

def minimum_platforms(arr, dep):
    arr.sort()
    dep.sort()
    n = len(arr)
    platforms = 1
    max_platforms = 1
    i = 1
    j = 0

    while i < n and j < n:
        if arr[i] <= dep[j]:
            platforms += 1
            i += 1
        else:
            platforms -= 1
            j += 1
        max_platforms = max(max_platforms, platforms)

    return max_platforms


if __name__ == "__main__":
    arr = [900, 940, 950, 1100, 1500, 1800]
    dep = [910, 1200, 1120, 1130, 1900, 2000]
    print(minimum_platforms(arr, dep))  # 3

    arr2 = [900, 1235, 1100]
    dep2 = [1000, 1240, 1200]
    print(minimum_platforms(arr2, dep2))  # 1
