# GFG: K-th element of two Arrays
# Difficulty: Medium | Submissions: 397K | Accuracy: 37.4%
# Link: https://www.geeksforgeeks.org/problems/k-th-element-of-two-sorted-array1317/1
#
# Problem: Given two sorted arrays, find the k-th element in their merged sorted form.
# Approach: Binary Search — O(log(min(n,m))) time, O(1) space

def kth_element(a, b, k):
    if len(a) > len(b):
        return kth_element(b, a, k)

    n, m = len(a), len(b)
    lo, hi = max(0, k - m), min(k, n)

    while lo <= hi:
        cut1 = (lo + hi) // 2
        cut2 = k - cut1

        l1 = a[cut1 - 1] if cut1 > 0 else float('-inf')
        l2 = b[cut2 - 1] if cut2 > 0 else float('-inf')
        r1 = a[cut1]     if cut1 < n else float('inf')
        r2 = b[cut2]     if cut2 < m else float('inf')

        if l1 <= r2 and l2 <= r1:
            return max(l1, l2)
        elif l1 > r2:
            hi = cut1 - 1
        else:
            lo = cut1 + 1

    return -1


if __name__ == "__main__":
    print(kth_element([2, 3, 6, 7, 9], [1, 4, 8, 10], 5))  # 6
    print(kth_element([100, 112, 256, 349, 770], [72, 86, 113, 119, 265, 445, 892], 7))  # 256
