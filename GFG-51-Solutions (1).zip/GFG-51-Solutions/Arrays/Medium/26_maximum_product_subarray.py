# GFG: Maximum Product Subarray
# Difficulty: Medium | Submissions: 505K | Accuracy: 18.09%
# Link: https://www.geeksforgeeks.org/problems/maximum-product-subarray3604/1
#
# Problem: Find subarray with maximum product.
# Approach: Track max & min (negatives can flip) — O(n) time, O(1) space

def max_product_subarray(arr):
    max_prod = min_prod = result = arr[0]

    for val in arr[1:]:
        candidates = (val, max_prod * val, min_prod * val)
        max_prod = max(candidates)
        min_prod = min(candidates)
        result = max(result, max_prod)

    return result


if __name__ == "__main__":
    print(max_product_subarray([2, 3, -2, 4]))       # 6
    print(max_product_subarray([-2, 0, -1]))          # 0
    print(max_product_subarray([-2, 3, -4]))          # 24
    print(max_product_subarray([-1, -2, -3, -4]))     # 24
