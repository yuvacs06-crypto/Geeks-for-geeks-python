# GFG: Longest Subarray with Sum K
# Difficulty: Medium | Submissions: 795K | Accuracy: 24.64%
# Link: https://www.geeksforgeeks.org/problems/longest-sub-array-with-sum-k0809/1
#
# Problem: Array can have negatives. Find length of longest subarray with sum = K.
# Approach: Prefix Sum + HashMap — O(n) time, O(n) space

def longest_subarray_sum_k(arr, k):
    prefix_map = {}
    prefix_sum = 0
    max_len = 0
    for i, val in enumerate(arr):
        prefix_sum += val
        if prefix_sum == k:
            max_len = i + 1
        if (prefix_sum - k) in prefix_map:
            max_len = max(max_len, i - prefix_map[prefix_sum - k])
        if prefix_sum not in prefix_map:
            prefix_map[prefix_sum] = i
    return max_len


if __name__ == "__main__":
    print(longest_subarray_sum_k([10, 5, 2, 7, 1, -10], 15))   # 6
    print(longest_subarray_sum_k([-5, 8, -14, 2, 4, 12], -5))  # 5
    print(longest_subarray_sum_k([10, -10, 20, 30], 5))         # 0
