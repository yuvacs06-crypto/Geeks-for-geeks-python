# GFG: Minimum Number of Jumps
# Difficulty: Medium | Submissions: 1M | Accuracy: 11.91%
# Link: https://www.geeksforgeeks.org/problems/minimum-number-of-jumps-1587115620/1
#
# Problem: Each element = max jump from that index. Min jumps to reach end.
# Approach: Greedy — O(n) time, O(1) space

def min_jumps(arr):
    n = len(arr)
    if n <= 1: return 0
    if arr[0] == 0: return -1

    jumps = 0
    curr_end = farthest = 0

    for i in range(n - 1):
        farthest = max(farthest, i + arr[i])
        if i == curr_end:
            jumps += 1
            curr_end = farthest
            if curr_end >= n - 1: return jumps
            if curr_end == i: return -1

    return jumps


if __name__ == "__main__":
    print(min_jumps([1, 3, 5, 8, 9, 2, 6, 7, 6, 8, 9]))  # 3
    print(min_jumps([1, 4, 3, 2, 6, 7]))                  # 2
    print(min_jumps([0, 10, 20]))                          # -1
