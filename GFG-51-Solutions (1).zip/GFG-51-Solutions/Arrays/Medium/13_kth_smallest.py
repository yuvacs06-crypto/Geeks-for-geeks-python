# GFG: Kth Smallest Element
# Difficulty: Medium | Submissions: 745K | Accuracy: 35.17%
# Link: https://www.geeksforgeeks.org/problems/kth-smallest-element5635/1
#
# Problem: Find Kth smallest element in unsorted array.
# Approach: Max-Heap of size k — O(n log k) time, O(k) space

import heapq

def kth_smallest(arr, k):
    max_heap = []
    for val in arr:
        heapq.heappush(max_heap, -val)
        if len(max_heap) > k:
            heapq.heappop(max_heap)
    return -max_heap[0]


if __name__ == "__main__":
    print(kth_smallest([7, 10, 4, 3, 20, 15], 3))  # 7
    print(kth_smallest([7, 10, 4, 20, 15], 4))      # 15
