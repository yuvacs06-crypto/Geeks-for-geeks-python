# GFG: Equilibrium Point
# Difficulty: Easy | Submissions: 686K | Accuracy: 28.13%
# Link: https://www.geeksforgeeks.org/problems/equilibrium-point-1587115620/1
#
# Problem: Find index where left sum == right sum. Return -1 if none.
# Approach: Prefix Sum — O(n) time, O(1) space

def equilibrium_point(arr):
    total = sum(arr)
    left_sum = 0
    for i, val in enumerate(arr):
        right_sum = total - left_sum - val
        if left_sum == right_sum:
            return i + 1   # 1-based index
        left_sum += val
    return -1


if __name__ == "__main__":
    print(equilibrium_point([1, 3, 5, 2, 2]))        # 3
    print(equilibrium_point([1]))                    # 1
    print(equilibrium_point([1, 2, 3]))              # -1
    print(equilibrium_point([3, 4, 8, -9, 20, 6]))  # 4
