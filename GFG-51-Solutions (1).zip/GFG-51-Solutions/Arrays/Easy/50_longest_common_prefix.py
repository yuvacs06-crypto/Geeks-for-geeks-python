# GFG: Longest Common Prefix of Strings
# Difficulty: Easy | Submissions: 319K | Accuracy: 29.52%
# Link: https://www.geeksforgeeks.org/problems/longest-common-prefix-in-an-array5129/1
#
# Problem: Find longest common prefix among all strings in array.
# Approach: Sort + compare first & last — O(n log n) time, O(1) extra space

def longest_common_prefix(arr):
    if not arr:
        return ""

    arr.sort()
    first, last = arr[0], arr[-1]
    prefix = []

    for c1, c2 in zip(first, last):
        if c1 == c2:
            prefix.append(c1)
        else:
            break

    return "".join(prefix)


if __name__ == "__main__":
    print(longest_common_prefix(["geeksforgeeks", "geeks", "geek", "geezer"]))  # "gee"
    print(longest_common_prefix(["apple", "ape", "april"]))                     # "ap"
    print(longest_common_prefix(["dog", "car"]))                                # ""
