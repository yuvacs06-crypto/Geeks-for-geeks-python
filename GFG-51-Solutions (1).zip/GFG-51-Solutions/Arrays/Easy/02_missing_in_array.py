# GFG: Missing in Array
# Difficulty: Easy | Submissions: 2M | Accuracy: 29.59%
# Link: https://www.geeksforgeeks.org/problems/missing-number-in-array1416/1
#
# Problem: Array of size n-1 with integers 1–n. Find the missing number.
# Approach: XOR — O(n) time, O(1) space

def missing_number(arr, n):
    xor_all = 0
    for i in range(1, n + 1):
        xor_all ^= i
    for val in arr:
        xor_all ^= val
    return xor_all


# Alternative: Sum formula
def missing_number_sum(arr, n):
    return n * (n + 1) // 2 - sum(arr)


if __name__ == "__main__":
    print(missing_number([1, 2, 3, 5], 5))      # 4
    print(missing_number_sum([1, 2, 4, 5], 5))  # 3
