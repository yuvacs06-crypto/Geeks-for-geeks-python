# GFG: First Repeating Element
# Difficulty: Easy | Submissions: 327K | Accuracy: 32.57%
# Link: https://www.geeksforgeeks.org/problems/first-repeating-element4018/1
#
# Problem: Find the first repeating element (1-based index). Return -1 if none.
# Approach: Traverse from right using set — O(n) time, O(n) space

def first_repeating(arr):
    seen = set()
    result = -1

    for i in range(len(arr) - 1, -1, -1):
        if arr[i] in seen:
            result = i + 1   # 1-based
        else:
            seen.add(arr[i])

    return result


if __name__ == "__main__":
    print(first_repeating([1, 5, 3, 4, 3, 5, 6]))  # 2  (5 at index 2, 1-based)
    print(first_repeating([1, 2, 3, 4]))            # -1
    print(first_repeating([1, 1, 1, 1]))            # 1
