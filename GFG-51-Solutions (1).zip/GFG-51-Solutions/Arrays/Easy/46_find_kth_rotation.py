# GFG: Find Kth Rotation
# Difficulty: Easy | Submissions: 348K | Accuracy: 23.16%
# Link: https://www.geeksforgeeks.org/problems/rotation4723/1
#
# Problem: Sorted array rotated k times. Find k (number of rotations).
# Approach: Find index of minimum element = number of rotations — O(log n)

def find_kth_rotation(arr):
    lo, hi = 0, len(arr) - 1

    # If already sorted (0 rotations)
    if arr[lo] <= arr[hi]:
        return 0

    while lo <= hi:
        mid = (lo + hi) // 2
        # Check if mid+1 is the minimum
        if arr[mid] > arr[mid + 1]:
            return mid + 1
        # Check if mid is the minimum
        if arr[mid] < arr[mid - 1]:
            return mid
        # Decide which half to search
        if arr[mid] >= arr[0]:
            lo = mid + 1
        else:
            hi = mid - 1

    return 0


if __name__ == "__main__":
    print(find_kth_rotation([15, 18, 2, 3, 6, 12]))   # 2
    print(find_kth_rotation([7, 9, 11, 12, 5]))        # 4
    print(find_kth_rotation([1, 2, 3, 4, 5]))          # 0
