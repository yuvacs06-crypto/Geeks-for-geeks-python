# GFG: Check Equal Arrays
# Difficulty: Easy | Submissions: 427K | Accuracy: 42.18%
# Link: https://www.geeksforgeeks.org/problems/check-if-two-arrays-are-equal-or-not3847/1
#
# Problem: Check if two arrays are equal (same elements, same frequencies).
# Approach: Frequency Map — O(n) time, O(n) space

from collections import Counter

def check_equal(a, b):
    if len(a) != len(b):
        return False
    return Counter(a) == Counter(b)


if __name__ == "__main__":
    print(check_equal([1, 2, 5, 4, 0], [2, 4, 5, 0, 1]))   # True
    print(check_equal([1, 2, 3], [1, 2, 4]))                # False
    print(check_equal([1, 1, 2], [1, 2, 2]))                # False
