# GFG: Number of occurrence
# Difficulty: Easy | Submissions: 387K | Accuracy: 59.34%
# Link: https://www.geeksforgeeks.org/problems/number-of-occurrence2259/1
#
# Problem: Count occurrences of a target in a sorted array.
# Approach: Binary Search (first & last index) — O(log n) time, O(1) space

def count_occurrences(arr, target):
    def first(t):
        lo, hi, res = 0, len(arr) - 1, -1
        while lo <= hi:
            mid = (lo + hi) // 2
            if arr[mid] == t: res = mid; hi = mid - 1
            elif arr[mid] < t: lo = mid + 1
            else: hi = mid - 1
        return res

    def last(t):
        lo, hi, res = 0, len(arr) - 1, -1
        while lo <= hi:
            mid = (lo + hi) // 2
            if arr[mid] == t: res = mid; lo = mid + 1
            elif arr[mid] < t: lo = mid + 1
            else: hi = mid - 1
        return res

    f, l = first(target), last(target)
    return 0 if f == -1 else l - f + 1


if __name__ == "__main__":
    print(count_occurrences([1, 1, 2, 2, 2, 2, 3], 2))  # 4
    print(count_occurrences([1, 1, 2, 2, 2, 2, 3], 4))  # 0
    print(count_occurrences([8, 9, 10, 12, 12, 12], 12))  # 3
