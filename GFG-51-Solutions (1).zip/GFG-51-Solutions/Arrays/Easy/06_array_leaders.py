# GFG: Array Leaders
# Difficulty: Easy | Submissions: 991K | Accuracy: 29.94%
# Link: https://www.geeksforgeeks.org/problems/leaders-in-an-array-1587115620/1
#
# Problem: Element is leader if greater than all to its right. Return all leaders.
# Approach: Right traversal — O(n) time, O(1) extra space

def array_leaders(arr):
    result = [arr[-1]]
    max_right = arr[-1]
    for i in range(len(arr) - 2, -1, -1):
        if arr[i] >= max_right:
            max_right = arr[i]
            result.append(arr[i])
    return result[::-1]


if __name__ == "__main__":
    print(array_leaders([16, 17, 4, 3, 5, 2]))  # [17, 5, 2]
    print(array_leaders([1, 2, 3, 4, 5]))       # [5]
    print(array_leaders([10, 4, 2, 3]))         # [10, 3]
