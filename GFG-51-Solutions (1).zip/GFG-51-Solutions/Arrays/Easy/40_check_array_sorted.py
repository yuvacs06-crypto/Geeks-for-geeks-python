# GFG: Check if Array is Sorted
# Difficulty: Easy | Submissions: 369K | Accuracy: 39.37%
# Link: https://www.geeksforgeeks.org/problems/check-if-an-array-is-sorted0701/1
#
# Problem: Check if array is sorted in non-decreasing order.
# Approach: Single Pass — O(n) time, O(1) space

def is_sorted(arr):
    for i in range(1, len(arr)):
        if arr[i] < arr[i - 1]:
            return False
    return True


if __name__ == "__main__":
    print(is_sorted([1, 2, 3, 4, 5]))    # True
    print(is_sorted([1, 2, 2, 3, 4]))    # True
    print(is_sorted([5, 4, 3, 2, 1]))    # False
    print(is_sorted([10]))               # True
