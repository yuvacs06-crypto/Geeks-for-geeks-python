# GFG: Frequencies in a Limited Array
# Difficulty: Easy | Submissions: 394K | Accuracy: 27.64%
# Link: https://www.geeksforgeeks.org/problems/frequency-of-array-elements-1587115620/1
#
# Problem: Array of size n with elements 1 to n. Count frequency of each element.
# Approach: Index Counting (no extra space) — O(n) time, O(1) space

def frequency_count(arr):
    n = len(arr)

    # Encode: add n to arr[arr[i]-1] to count occurrences
    for i in range(n):
        idx = (arr[i] - 1) % n
        arr[idx] += n

    # Decode: frequency = arr[i] // n
    return [arr[i] // n for i in range(n)]


if __name__ == "__main__":
    print(frequency_count([2, 3, 2, 3, 5]))      # [0, 2, 2, 0, 1]
    print(frequency_count([3, 3, 3, 3]))          # [0, 0, 4, 0]
    print(frequency_count([1, 2, 3, 4, 5]))       # [1, 1, 1, 1, 1]
