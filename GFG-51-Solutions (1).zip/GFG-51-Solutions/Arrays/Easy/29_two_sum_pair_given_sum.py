# GFG: Two Sum - Pair with Given Sum
# Difficulty: Easy | Submissions: 461K | Accuracy: 30.61%
# Link: https://www.geeksforgeeks.org/problems/key-pair5616/1
#
# Problem: Check if any pair in array sums to target.
# Approach: HashSet — O(n) time, O(n) space

def two_sum(arr, target):
    seen = set()
    for val in arr:
        if (target - val) in seen:
            return True
        seen.add(val)
    return False


if __name__ == "__main__":
    print(two_sum([1, 4, 45, 6, 10, 8], 16))   # True  (6 + 10)
    print(two_sum([1, 2, 4, 3, 6], 11))         # False
    print(two_sum([0, -1, 2, -3, 1], -2))       # True  (-3 + 1)
