# GFG: Second Largest
# Difficulty: Easy | Submissions: 1M | Accuracy: 26.72%
# Link: https://www.geeksforgeeks.org/problems/second-largest3735/1
#
# Problem: Find the second largest distinct element. Return -1 if not found.
# Approach: Single Pass — O(n) time, O(1) space

def get_second_largest(arr):
    largest = second = -1
    for val in arr:
        if val > largest:
            second = largest
            largest = val
        elif val > second and val != largest:
            second = val
    return second


if __name__ == "__main__":
    print(get_second_largest([12, 35, 1, 10, 34, 1]))  # 34
    print(get_second_largest([10, 10, 10]))             # -1
    print(get_second_largest([5, 5, 4]))                # 4
