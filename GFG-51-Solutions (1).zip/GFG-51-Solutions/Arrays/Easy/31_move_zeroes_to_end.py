# GFG: Move All Zeroes to End
# Difficulty: Easy | Submissions: 440K | Accuracy: 45.51%
# Link: https://www.geeksforgeeks.org/problems/move-all-zeroes-to-end-of-array0751/1
#
# Problem: Move all zeros to end while maintaining order of non-zero elements.
# Approach: Two Pointer — O(n) time, O(1) space

def move_zeroes(arr):
    pos = 0  # position for next non-zero

    for val in arr:
        if val != 0:
            arr[pos] = val
            pos += 1

    while pos < len(arr):
        arr[pos] = 0
        pos += 1


if __name__ == "__main__":
    a = [1, 2, 0, 4, 3, 0, 5, 0]; move_zeroes(a); print(a)  # [1,2,4,3,5,0,0,0]
    b = [10, 20, 30]; move_zeroes(b); print(b)               # [10,20,30]
    c = [0, 0]; move_zeroes(c); print(c)                     # [0,0]
