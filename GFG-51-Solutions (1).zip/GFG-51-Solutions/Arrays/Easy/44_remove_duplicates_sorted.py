# GFG: Remove Duplicates Sorted Array
# Difficulty: Easy | Submissions: 360K | Accuracy: 38.18%
# Link: https://www.geeksforgeeks.org/problems/remove-duplicate-elements-from-sorted-array/1
#
# Problem: Remove duplicates from sorted array in-place. Return count of unique elements.
# Approach: Two Pointer — O(n) time, O(1) space

def remove_duplicates(arr):
    if not arr:
        return 0

    pos = 1  # position for next unique element

    for i in range(1, len(arr)):
        if arr[i] != arr[i - 1]:
            arr[pos] = arr[i]
            pos += 1

    return pos   # count of unique elements


if __name__ == "__main__":
    a = [2, 2, 2, 2, 2]; k = remove_duplicates(a); print(k, a[:k])    # 1 [2]
    b = [1, 2, 2, 3, 4]; k = remove_duplicates(b); print(k, b[:k])    # 4 [1,2,3,4]
    c = [1, 1, 2];       k = remove_duplicates(c); print(k, c[:k])    # 2 [1,2]
