# GFG: Binary Search
# Difficulty: Easy | Submissions: 713K | Accuracy: 44.32%
# Link: https://www.geeksforgeeks.org/problems/binary-search-1587115620/1
#
# Problem: Sorted array; return index of target, else -1.
# Approach: Iterative Binary Search — O(log n) time, O(1) space

def binary_search(arr, target):
    lo, hi = 0, len(arr) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if arr[mid] == target: return mid
        elif arr[mid] < target: lo = mid + 1
        else: hi = mid - 1
    return -1


if __name__ == "__main__":
    arr = [1, 3, 5, 7, 9, 11]
    print(binary_search(arr, 7))   # 3
    print(binary_search(arr, 6))   # -1
    print(binary_search(arr, 1))   # 0
