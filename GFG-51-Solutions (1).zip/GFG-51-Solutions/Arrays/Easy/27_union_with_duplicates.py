# GFG: Union of Arrays with Duplicates
# Difficulty: Easy | Submissions: 497K | Accuracy: 42.22%
# Link: https://www.geeksforgeeks.org/problems/union-of-two-arrays3538/1
#
# Problem: Return count of distinct elements in union of two arrays.
# Approach: Set union — O(n + m) time, O(n + m) space

def union_with_duplicates(a, b):
    return len(set(a) | set(b))


if __name__ == "__main__":
    print(union_with_duplicates([1, 2, 3, 4, 5], [1, 2, 3]))          # 5
    print(union_with_duplicates([85, 25, 1, 32, 54, 6], [85, 2]))     # 7
    print(union_with_duplicates([1, 2, 1, 1, 2], [2, 2, 1, 2, 1]))   # 2
