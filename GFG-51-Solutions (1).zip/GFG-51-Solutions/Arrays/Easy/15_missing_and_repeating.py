# GFG: Missing and Repeating
# Difficulty: Easy | Submissions: 689K | Accuracy: 24.83%
# Link: https://www.geeksforgeeks.org/problems/find-missing-and-repeating2512/1
#
# Problem: Array 1–n with one repeated, one missing. Return [repeating, missing].
# Approach: Math (sum + sum of squares) — O(n) time, O(1) space

def find_two_element(arr):
    n = len(arr)
    sum_n    = n * (n + 1) // 2
    sum_sq_n = n * (n + 1) * (2 * n + 1) // 6
    s, sq    = sum(arr), sum(x * x for x in arr)

    diff   = s  - sum_n     # x - y
    sq_diff = sq - sum_sq_n  # x² - y²
    total  = sq_diff // diff  # x + y

    repeating = (total + diff) // 2
    missing   = (total - diff) // 2
    return [repeating, missing]


if __name__ == "__main__":
    print(find_two_element([2, 2]))               # [2, 1]
    print(find_two_element([1, 3, 3]))            # [3, 2]
    print(find_two_element([4, 3, 6, 2, 1, 1]))  # [1, 5]
