# GFG: Two Sum - Pairs with 0 Sum
# Difficulty: Easy | Submissions: 530K | Accuracy: 31.49%
# Link: https://www.geeksforgeeks.org/problems/pairs-with-specific-difference1533/1
#
# Problem: Find all pairs in array whose sum is 0.
# Approach: HashSet — O(n) time, O(n) space

def pairs_with_zero_sum(arr):
    seen = set()
    result = []
    for val in arr:
        if -val in seen:
            pair = (min(val, -val), max(val, -val))
            if pair not in result:
                result.append(pair)
        seen.add(val)
    return result


if __name__ == "__main__":
    print(pairs_with_zero_sum([-1, 0, 1, 2, -1, -4]))  # [(-1, 1)]
    print(pairs_with_zero_sum([6, 1, 8, 0, -4, -6]))   # [(-6, 6)]
    print(pairs_with_zero_sum([0, 0]))                  # [(0, 0)]
