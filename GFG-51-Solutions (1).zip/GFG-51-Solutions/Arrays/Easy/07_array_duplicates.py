# GFG: Array Duplicates
# Difficulty: Easy | Submissions: 899K | Accuracy: 18.95%
# Link: https://www.geeksforgeeks.org/problems/find-duplicates-in-an-array/1
#
# Problem: Array of size n with elements 0 to n-1. Find all duplicates.
# Approach: Index negation — O(n) time, O(1) extra space

def find_duplicates(arr):
    result = []
    for i in range(len(arr)):
        idx = abs(arr[i])
        if arr[idx] < 0:
            result.append(idx)
        else:
            arr[idx] = -arr[idx]
    return sorted(result) if result else [-1]


if __name__ == "__main__":
    print(find_duplicates([2, 3, 1, 2, 3]))  # [2, 3]
    print(find_duplicates([0, 3, 1, 2]))     # [-1]
