# GFG: Trapping Rain Water
# Difficulty: Hard | Submissions: 510K | Accuracy: 33.14%
# Link: https://www.geeksforgeeks.org/problems/trapping-rain-water-1587115621/1
#
# Problem: Given heights of bars, find total water trapped between them.
# Approach: Two Pointer — O(n) time, O(1) space

def trap_water(arr):
    lo, hi = 0, len(arr) - 1
    left_max = right_max = 0
    water = 0

    while lo <= hi:
        if arr[lo] <= arr[hi]:
            if arr[lo] >= left_max:
                left_max = arr[lo]
            else:
                water += left_max - arr[lo]
            lo += 1
        else:
            if arr[hi] >= right_max:
                right_max = arr[hi]
            else:
                water += right_max - arr[hi]
            hi -= 1

    return water


if __name__ == "__main__":
    print(trap_water([3, 0, 1, 0, 4, 0, 2]))  # 10
    print(trap_water([0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1]))  # 6
    print(trap_water([1, 2, 3, 4]))            # 0
